package ust.MavenProject.demo;

public class Employee implements Person{

	@Override
	public void name() {
		System.out.println("i am in employee name method");
		
	}

	@Override
	public void exeperince() {
		System.out.println("i am in employee experience method");
		
	}
	

}
