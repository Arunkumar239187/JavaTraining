package ust.MavenProject.demo;

public interface Person {

	public void name();
	public void exeperince();
}
