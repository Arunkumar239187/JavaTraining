package ust.MavenProject.demo;

public class BussinessPerson implements Person{

	@Override
	public void name() {
		System.out.println("i am in Bussiness name method");
		
	}

	@Override
	public void exeperince() {
		System.out.println("i am in Bussiness Experince method");
		
	}

}
