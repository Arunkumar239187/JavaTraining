package streamTest;

public class SalDetect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
