package inhertance;

public class Vehicle {
String type;

}

