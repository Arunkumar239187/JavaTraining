package check;
@FunctionalInterface
public interface Funct {
	public abstract int display(int a,int b);
}